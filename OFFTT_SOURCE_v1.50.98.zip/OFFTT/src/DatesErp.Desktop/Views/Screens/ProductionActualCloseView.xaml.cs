using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Globalization;
using System.Windows.Input;
using System.Windows;
using System.Windows.Controls;
using DatesErp.Core.Interfaces.Services;
using DatesErp.Desktop.Services;
using Microsoft.Extensions.DependencyInjection;

namespace DatesErp.Desktop.Views.Screens;

/// <summary>
/// شاشة الإنتاج الوحيدة لتسجيل الكميات الفعلية وإقفال جلسات التنفيذ.
/// لا تنشئ أو تحرر مستند تسليم أو استلاماً مخزنياً ولا حركة مخزون.
/// </summary>
public partial class ProductionActualCloseView : UserControl
{
    public static int? PendingOrderId { get; set; }
    public ObservableCollection<ActualByProductDefinitionDto> ByProductDefinitions { get; } = new();
    public ObservableCollection<ActualByProductSourceDto> ByProductSources { get; } = new();

    private readonly ObservableCollection<ActualProductionRow> _items = new();
    private readonly ObservableCollection<ActualSecondaryRow> _secondary = new();
    private List<ActualByProductDefinitionDto> _activeDefinitions = new();
    private readonly Func<IProductionDeliveryService> _serviceResolver;
    private readonly Action<string> _showSavedMessage;
    private bool _saving;
    private bool _searchPerformed;
    private string _lastSearchText = "";

    private static bool CanProduction(string action)
        => DatesErp.Desktop.Views.PermissionGate.Can("production", action);

    public ProductionActualCloseView() : this(null, null) { }

    /// <summary>اختيار مزود الخدمة ورسالة النجاح يسمح بفحص سلوك الواجهة على قاعدة اختبار معزولة.</summary>
    public ProductionActualCloseView(Func<IProductionDeliveryService> serviceResolver, Action<string> showSavedMessage)
    {
        _serviceResolver = serviceResolver;
        _showSavedMessage = showSavedMessage ?? (message => MessageBox.Show(message,
            "تم إقفال الإنتاج وتسجيل الفعلي", MessageBoxButton.OK, MessageBoxImage.Information));
        InitializeComponent();
        ItemsGrid.ItemsSource = _items;
        SecondaryGrid.ItemsSource = _secondary;
        _secondary.CollectionChanged += Secondary_CollectionChanged;
        _items.CollectionChanged += Items_CollectionChanged;
        NewSession();
        Loaded += (_, _) => LoadOrders(PendingOrderId);
    }

    public void AttachChrome(Views.ErpChrome chrome)
    {
        chrome.SetModule("إقفال الإنتاج وتسجيل الفعلي");
        chrome.SetScreenCode("MRPMPS1022");
        chrome.SetPermissionModule("production");
        chrome.SetToolbar(new Views.ErpToolbar()
            .WithNew((_, _) => NewSession(), "جلسة تسجيل فعلية جديدة")
            .WithSearch((_, _) => { OrderSearchBox.Focus(); OrderSearchBox.SelectAll(); SearchOrders_Click(null, null); }, "بحث في أوامر الإنتاج والتنفيذات المحفوظة")
            .WithSaveForCreateOrEdit((_, _) => Save_Click(null, null), "حفظ الفعلي وإقفال الجلسة")
            .WithUndo((_, _) => ReloadCurrent(), "تراجع عن الإدخال غير المحفوظ وإعادة تحميل السجل")
            .WithRefresh((_, _) => ReloadCurrent())
            .WithPrint((_, _) => Print(), "طباعة ملخص التنفيذ المحفوظ")
            .WithExit((_, _) => (Window.GetWindow(this) as MainWindow)?.OpenPreviousScreen()));
        chrome.SetBody(this);
        chrome.CloseRequested += (_, _) => (Window.GetWindow(this) as MainWindow)?.OpenPreviousScreen();
    }

    public static void OpenForOrder(int orderId, Window source)
    {
        PendingOrderId = orderId;
        var main = System.Windows.Application.Current.MainWindow as MainWindow;
        if (source != null && source != main) source.Close();
        main?.OpenScreen("actualclose");
    }

    private T WithService<T>(Func<IProductionDeliveryService, T> action)
    {
        if (_serviceResolver != null) return action(_serviceResolver());
        using var scope = AppContainer.NewScope();
        return action(scope.ServiceProvider.GetRequiredService<IProductionDeliveryService>());
    }

    private void LoadOrders(int? selected, bool includeCompleted = false, string searchText = null)
    {
        try
        {
            _activeDefinitions = WithService(s => s.GetActualByProducts());
            ByProductDefinitions.Clear();
            foreach (var definition in _activeDefinitions) ByProductDefinitions.Add(definition);

            if (!selected.HasValue && !includeCompleted && !_searchPerformed)
            {
                OrderBox.ItemsSource = Array.Empty<ActualDeliveryOrderDto>();
                OrderBox.SelectedItem = null;
                StatusLabel.Text = "ابدأ بالبحث عن أمر إنتاج؛ لا تُعرض الأوامر قبل طلب البحث.";
                return;
            }

            var orders = WithService(s => s.GetActualDeliveryOrders(selected, includeCompleted))
                .Where(o => o.CanRecord || (includeCompleted && o.Recorded) || o.OrderId == selected)
                .Where(o => string.IsNullOrWhiteSpace(searchText)
                    || (o.Label ?? "").Contains(searchText, StringComparison.CurrentCultureIgnoreCase)
                    || (o.OrderNumber ?? "").Contains(searchText, StringComparison.CurrentCultureIgnoreCase)
                    || (o.Customer ?? "").Contains(searchText, StringComparison.CurrentCultureIgnoreCase)
                    || (o.PlanNumber ?? "").Contains(searchText, StringComparison.CurrentCultureIgnoreCase)
                    || o.Items.Any(i => (i.Product ?? "").Contains(searchText, StringComparison.CurrentCultureIgnoreCase)))
                .ToList();
            OrderBox.ItemsSource = orders;
            OrderBox.SelectedItem = orders.FirstOrDefault(o => o.OrderId == selected)
                ?? orders.FirstOrDefault(o => o.CanRecord)
                ?? orders.FirstOrDefault();
            PendingOrderId = null;
            if (orders.Count == 0)
                StatusLabel.Text = includeCompleted
                    ? "لم يعثر البحث على أمر أو تنفيذ محفوظ مطابق. غيّر عبارة البحث أو امسحها."
                    : "لا توجد أوامر معتمدة قابلة لتسجيل الفعلي؛ استخدم بحثًا للرجوع إلى التنفيذات المحفوظة.";
        }
        catch (Exception ex)
        {
            StatusLabel.Text = "تعذر تحميل أوامر الإنتاج: " + ex.Message;
            AppContainer.Get<DialogService>().HandleException(ex, "ActualClose.Load");
        }
    }

    private void NewSession()
    {
        if (OrderBox == null) return;
        OrderBox.SelectedItem = null;
        _items.Clear();
        _secondary.Clear();
        ByProductSources.Clear();
        RawBox.Text = ""; DowntimeBox.Text = "0"; ReasonBox.Text = ""; NotesBox.Text = "";
        StatusLabel.Text = "جلسة جديدة: اختر أمرًا قابلًا للتسجيل من القائمة أو ابحث عنه، ثم أدخل الفعلي لكل بند.";
        ItemsGrid.IsReadOnly = true;
        MeasurementsPanel.IsEnabled = false;
        ByProductsPanel.IsEnabled = false;
        SaveActualButton.IsEnabled = false;
        RefreshSummaries();
    }

    private void SearchOrders_Click(object sender, RoutedEventArgs e)
    {
        string query = (OrderSearchBox.Text ?? "").Trim();
        _searchPerformed = true;
        _lastSearchText = query;
        LoadOrders(null, includeCompleted: true, searchText: query);
        if (OrderBox.Items.Count == 1) OrderBox.SelectedIndex = 0;
        OrderSearchBox.Focus();
        OrderSearchBox.SelectAll();
    }

    private void OrderSearch_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter) SearchOrders_Click(sender, e);
    }

    private void ReloadCurrent()
    {
        if (OrderBox.SelectedItem is ActualDeliveryOrderDto selected)
            LoadOrders(selected.OrderId, includeCompleted: true);
        else if (_searchPerformed)
            LoadOrders(null, includeCompleted: true, searchText: _lastSearchText);
        else
            LoadOrders(null, includeCompleted: false);
    }

    private void Order_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (ItemsGrid == null) return;
        var order = OrderBox.SelectedItem as ActualDeliveryOrderDto;
        _items.Clear();
        _secondary.Clear();
        ByProductSources.Clear();
        foreach (var source in order?.ByProductSources ?? new List<ActualByProductSourceDto>()) ByProductSources.Add(source);
        RawBox.Text = "";
        DowntimeBox.Text = "0";
        ReasonBox.Text = "";
        NotesBox.Text = "";
        ByProductDefinitions.Clear();
        foreach (var definition in _activeDefinitions) ByProductDefinitions.Add(definition);

        bool editable = order?.CanRecord == true && CanProduction("Create") && PermissionGate.Can("execution", "Edit");
        ItemsGrid.IsReadOnly = !editable;
        MeasurementsPanel.IsEnabled = editable;
        ByProductsPanel.IsEnabled = editable;
        SaveActualButton.IsEnabled = editable;

        CustChip.Text = $"👤 العميل: {order?.Customer ?? "—"}";
        PlanChip.Text = $"📋 الخطة: {order?.PlanNumber ?? "—"}";
        ShiftChip.Text = $"⏰ الوردية: {order?.Shift ?? "—"}";
        DateChip.Text = $"📅 التاريخ: {GetProductionDate(order) ?? "—"}";
        StatusLabel.Text = order?.Status ?? "اختر أمراً من الأعلى.";

        if (order == null) return;
        bool continuation = order.Recorded && order.CanRecord;
        bool historical = order.Recorded && !order.CanRecord;
        ItemsGrid.Columns[4].Header = continuation ? "فعلي هذه الجلسة ✏️"
            : historical ? "الإنتاج الفعلي التراكمي" : "المنتج فعليًا ✏️";
        foreach (var line in order.Items)
        {
            var row = new ActualProductionRow(line, historical, continuation);
            row.PropertyChanged += ActualRow_PropertyChanged;
            _items.Add(row);
        }

        if (order.Recorded && !continuation)
        {
            RawBox.Text = order.ConsumedRawKg.ToString(CultureInfo.CurrentCulture);
            DowntimeBox.Text = order.DowntimeHours.ToString(CultureInfo.CurrentCulture);
            ReasonBox.Text = order.DowntimeReason ?? "";
            NotesBox.Text = order.Notes ?? "";
            foreach (var byProduct in order.ByProducts)
            {
                _secondary.Add(new ActualSecondaryRow
                {
                    Definition = ByProductDefinitions.FirstOrDefault(x => x.Id == byProduct.ByProductId)
                        ?? new ActualByProductDefinitionDto { Id = byProduct.ByProductId, Name = $"مخرج محفوظ #{byProduct.ByProductId}", Unit = "كجم" },
                    Source = ByProductSources.FirstOrDefault(x => x.OrderItemId == byProduct.SourceOrderItemId
                        && x.RawProductId == byProduct.RawProductId && x.RawLotId == byProduct.RawLotId && x.CustomerId == byProduct.CustomerId),
                    Quantity = byProduct.QtyKg.ToString(CultureInfo.CurrentCulture)
                });
            }
            StatusLabel.Text += $" — آخر فحص: {order.QualityNumber ?? "بانتظار الفحص"}";
        }
        else
        {
            AddSecondaryRow();
            if (continuation)
            {
                RawBox.Text = "";
                DowntimeBox.Text = "0";
                ReasonBox.Text = "";
                NotesBox.Text = "";
                double remainingKg = Math.Max(0, order.PlannedQtyKg - order.ActualQtyKg);
                StatusLabel.Text += $" — سبق تسجيل {order.ActualQtyKg:N1} كجم؛ المتبقي المخطط {remainingKg:N1} كجم. أدخل كميات هذه الجلسة فقط.";
            }
            else if (!editable)
                StatusLabel.Text += " — التسجيل غير متاح للصلاحية الحالية أو لحالة الأمر.";
        }
    }

    private static string GetProductionDate(ActualDeliveryOrderDto order)
        => order?.ProductionDate;

    private void AddByProduct_Click(object sender, RoutedEventArgs e)
        => AddSecondaryRow();

    private void AddSecondaryRow()
    {
        _secondary.Add(new ActualSecondaryRow());
    }

    private void RemoveByProduct_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as FrameworkElement)?.DataContext is ActualSecondaryRow row)
            _secondary.Remove(row);
    }

    private void Save_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            if (_saving) return;
            if (OrderBox.SelectedItem is not ActualDeliveryOrderDto order)
            {
                StatusLabel.Text = "اختر أمر الإنتاج أولاً.";
                return;
            }
            if (!order.CanRecord)
            {
                StatusLabel.Text = "لا يمكن تسجيل الفعلي: " + (order.Status ?? "حالة الأمر لا تسمح بالإقفال.");
                return;
            }
            if (!CanProduction("Create") || !PermissionGate.Can("execution", "Edit"))
            {
                StatusLabel.Text = "لا يمكن الحفظ: يلزم صلاحية إنشاء الإنتاج وتعديل التنفيذ.";
                return;
            }

            ItemsGrid.CommitEdit(DataGridEditingUnit.Cell, true);
            ItemsGrid.CommitEdit(DataGridEditingUnit.Row, true);
            SecondaryGrid.CommitEdit(DataGridEditingUnit.Cell, true);
            SecondaryGrid.CommitEdit(DataGridEditingUnit.Row, true);

            if (_items.Count == 0 || _items.Any(i => !i.TryQuantity(out _)))
                throw new ArgumentException("أدخل الفعلي لكل بند، والصفر يُدخل صراحةً.");
            if (!ActualProductionRow.TryNonnegative(RawBox.Text, out var raw) || raw <= 0)
                throw new ArgumentException("أدخل الخام المستهلك فعلياً بالكيلو.");
            if (!ActualProductionRow.TryNonnegative(DowntimeBox.Text, out var hours))
                throw new ArgumentException("أدخل ساعات توقف صحيحة غير سالبة.");

            var input = new ActualProductionDto
            {
                OrderId = order.OrderId,
                ConsumedRawKg = raw,
                DowntimeHours = hours,
                DowntimeReason = ReasonBox.Text,
                Notes = NotesBox.Text
            };
            foreach (var row in _items)
            {
                row.TryQuantity(out var quantity);
                input.Items.Add(new ActualProductionItemDto { OrderItemId = row.Source.OrderItemId, ActualCartons = quantity });
            }
            foreach (var row in _secondary)
            {
                if (row.Definition == null && string.IsNullOrWhiteSpace(row.Quantity)) continue;
                if (row.Definition == null || !ActualProductionRow.TryNonnegative(row.Quantity, out var quantity) || quantity <= 0)
                    throw new ArgumentException("اختر المخرج الثانوي وأدخل كميته الموجبة، أو احذف السطر غير المستخدم.");
                if (row.Source == null)
                    throw new ArgumentException("اختر مصدر الخام والعميل والدفعة لكل مخرج ثانوي.");
                input.ByProducts.Add(new ByProductQtyDto
                {
                    ByProductId = row.Definition.Id, QtyKg = quantity,
                    SourceOrderItemId = row.Source.OrderItemId, RawProductId = row.Source.RawProductId,
                    RawLotId = row.Source.RawLotId, CustomerId = row.Source.CustomerId
                });
            }

            _saving = true;
            var result = WithService(s => s.SaveActualProduction(input));
            if (!result.Ok)
            {
                StatusLabel.Text = result.Message;
                return;
            }
            string successMessage = result.Message + "\n\nإذا بقي إنتاج مخطط، ابحث عن الأمر نفسه لاستكمال جلسة جديدة. لا تنفذ هذه الشاشة أي حركة مخزنية؛ استلام المنتج التام من اختصاص موظف المخزن.";
            _showSavedMessage(successMessage);
            _searchPerformed = false;
            _lastSearchText = "";
            OrderSearchBox.Text = "";
            LoadOrders(null, includeCompleted: false);
            NewSession();
            StatusLabel.Text = successMessage;
        }
        catch (ArgumentException ex)
        {
            StatusLabel.Text = ex.Message;
        }
        catch (Exception ex)
        {
            StatusLabel.Text = "ActualClose.Save: " + ex.Message;
            AppContainer.Get<DialogService>().HandleException(ex, "ActualClose.Save");
        }
        finally
        {
            _saving = false;
        }
    }

    private void Print()
    {
        try
        {
            if (OrderBox.SelectedItem is not ActualDeliveryOrderDto { Recorded: true, OrderId: > 0 } order)
            {
                StatusLabel.Text = "اختر تنفيذًا محفوظًا قبل الطباعة.";
                return;
            }
            using var scope = AppContainer.NewScope();
            var db = scope.ServiceProvider.GetRequiredService<DatesErp.Infrastructure.Persistence.DatesErpDbContext>();
            var model = Printing.StoredPrintModels.Execution(db, order.OrderId);
            new PrintPreviewWindow(PhasePrint.Build(model), $"{model.DocTitle} {model.DocNo}")
                { Owner = Window.GetWindow(this) }.ShowDialog();
        }
        catch (Exception ex)
        {
            StatusLabel.Text = "تعذرت الطباعة: " + ex.Message;
            AppContainer.Get<DialogService>().HandleException(ex, "ActualClose.Print");
        }
    }

    private void Secondary_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
    {
        if (e.OldItems != null) foreach (ActualSecondaryRow row in e.OldItems) row.PropertyChanged -= SecondaryRow_PropertyChanged;
        if (e.NewItems != null) foreach (ActualSecondaryRow row in e.NewItems) row.PropertyChanged += SecondaryRow_PropertyChanged;
        RefreshSummaries();
    }

    private void Items_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e) => RefreshSummaries();
    private void ActualRow_PropertyChanged(object sender, PropertyChangedEventArgs e) => RefreshSummaries();
    private void SecondaryRow_PropertyChanged(object sender, PropertyChangedEventArgs e) => RefreshSummaries();

    private void RefreshSummaries()
    {
        if (SecondaryTotalsLabel == null) return;
        double secondaryTotal = _secondary.Select(r => ActualProductionRow.TryNonnegative(r.Quantity, out var q) ? q : 0).Sum();
        SecondaryTotalsLabel.Text = $"إجمالي المخرجات الثانوية: {secondaryTotal:N2} كجم";
        if (ActualSummaryLabel != null)
        {
            int entered = _items.Count(r => r.TryQuantity(out _));
            int cartons = _items.Where(r => r.TryQuantity(out _)).Sum(r => { r.TryQuantity(out var q); return q; });
            int planned = _items.Sum(r => r.RemainingBefore + r.PreviouslyProduced);
            ActualSummaryLabel.Text = $"بنود مكتملة الإدخال: {entered}/{_items.Count} — الفعلي المُدخل: {cartons:N0} / {planned:N0} كرتون";
        }
    }
}
