using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using DatesErp.Application.Services;
using DatesErp.Core.Common;
using DatesErp.Core.Interfaces.Services;
using DatesErp.Desktop.Services;
using DatesErp.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace DatesErp.Desktop.Views.Screens;

public class DelivBalanceRow : System.ComponentModel.INotifyPropertyChanged
{
    private int _productId;
    private int? _lotId;
    private int? _packagingTypeId;
    private string _productName = "—";
    private string _lotCode = "— اختر الدفعة —";
    private double _qty;
    private int _packages;
    private double _unitWeight;
    private string _packName = "—";
    private string _unit = "—";
    private string _rowNotes = "";
    private int _rowIndex;

    public int RowIndex { get => _rowIndex; set { _rowIndex = value; OnChanged(nameof(RowIndex)); } }
    public string RowNotes { get => _rowNotes; set { _rowNotes = value ?? ""; OnChanged(nameof(RowNotes)); } }
    public int ProductId { get => _productId; set { _productId = value; OnChanged(nameof(ProductId)); OnChanged(nameof(IsEmptyRow)); } }
    public int? LotId { get => _lotId; set { _lotId = value; OnChanged(nameof(LotId)); OnChanged(nameof(IsEmptyRow)); } }
    public int? WarehouseId { get; set; }
    public string WarehouseName { get; set; } = "—";
    public int? PackagingTypeId { get => _packagingTypeId; set { _packagingTypeId = value; OnChanged(nameof(PackagingTypeId)); } }
    public string ProductName { get => _productName; set { _productName = value ?? "—"; OnChanged(nameof(ProductName)); } }
    public string LotCode { get => _lotCode; set { _lotCode = value ?? "—"; OnChanged(nameof(LotCode)); } }
    public double Qty { get => _qty; set { _qty = value; OnChanged(nameof(Qty)); } }
    public int Packages { get => _packages; set { _packages = value; _qty = value * (_unitWeight > 0 ? _unitWeight : (CartonWeight > 0 ? CartonWeight : 0)); OnChanged(nameof(Packages)); OnChanged(nameof(Qty)); OnChanged(nameof(IsInvalid)); OnChanged(nameof(ValidationError)); } }
    public double UnitWeight { get => _unitWeight; set { _unitWeight = value; OnChanged(nameof(UnitWeight)); } }
    public string PackName { get => _packName; set { _packName = value ?? "—"; OnChanged(nameof(PackName)); } }
    public string Unit { get => _unit; set { _unit = value ?? "—"; OnChanged(nameof(Unit)); } }
    public string QcStatus { get; set; }
    public string Code { get; set; } = "—";
    public string Grade { get; set; } = "—";
    public double CartonWeight { get; set; }
    public string FgReceipt { get; set; } = "—";
    public string Production { get; set; } = "—";
    public int StorageDays { get; set; }
    public string PlanNo { get; set; } = "—";
    public string OrderNo { get; set; } = "—";
    public bool QcReady { get; set; }

    // §1.50.56 — حقول إضافية للإدخال المباشر
    public double AvailableQty { get; set; }
    public int AvailablePackages { get; set; }
    public bool IsEmptyRow => ProductId == 0 && LotId == null;
    public bool IsInvalid => !IsEmptyRow && (Packages <= 0 || (AvailablePackages > 0 && Packages > AvailablePackages));
    public string ValidationError => IsInvalid ? (Packages <= 0 ? "أدخل كراتين > 0" : $"التجاوز: {Packages} > متاح {AvailablePackages}") : null;

    public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;
    private void OnChanged(string n) => PropertyChanged?.Invoke(this, new System.ComponentModel.PropertyChangedEventArgs(n));
}

/// <summary>تسليم العملاء — من رصيد العميل في مخزن التام فقط (لا تسليم دفعة عميل لعميل آخر، لا تسليم فوق الرصيد).</summary>
public partial class DeliveryView : UserControl
{
    private List<object> _deliveries_all = new();
    private readonly ObservableCollection<DelivBalanceRow> _balances = new();
    private readonly ObservableCollection<DelivBalanceRow> _items = new();
    private List<int> _deliveryIds = new();
    private int _currentId, _currentCustomerId;
    private bool _locked;
    private Views.ErpToolbar _toolbar;

    public DeliveryView()
    {
        InitializeComponent();
        BalanceGrid.ItemsSource = _balances;
        ItemsGrid.ItemsSource = _items;
        _items.CollectionChanged += (_, _) => UpdateSummary();

        // §قاعدة الكرتون: تعديل الكراتين يشتق الوزن المكافئ فوراً
        ItemsGrid.CellEditEnding += (_, e) =>
        {
            if (e.Row?.Item is DelivBalanceRow row)
            {
                if (row.Packages < 0) row.Packages = 0;
                double w2 = row.UnitWeight > 0 ? row.UnitWeight : (row.CartonWeight > 0 ? row.CartonWeight : 0);
                row.Qty = w2 > 0 ? Math.Round(row.Packages * w2, 2) : 0;
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    ItemsGrid.Items.Refresh();
                    UpdateSummary();
                }));
            }
        };

        ItemsGrid.PreviewKeyDown += ItemsGrid_PreviewKeyDown;
        Loaded += (_, _) => { Services.ComboBoxAutoShowHelper.Apply(this); Load(); };
    }

    public void AttachChrome(Views.ErpChrome chrome)
    {
        chrome.SetModule("المخازن والاستلام");
        chrome.SetScreenCode("MRPINV1005");
        chrome.SetPermissionModule("delivery");
        // §1 — الترتيب القياسي الموحد للأزرار الأساسية
        _toolbar = new Views.ErpToolbar()
            .WithNew((_, _) => NewForm(), "سند تسليم جديد (F2)")
            .WithSave((_, _) => Save(), "حفظ سند التسليم — يبقى السند أمامك كما هو (F10)")
            .WithSearch((_, _) => FocusDeliveries(), "بحث في سجل أذونات التسليم (F9)")
            .WithUndo((_, _) => UndoSmart(), "تراجع: يلغي الإدخالات غير المحفوظة ويعيد آخر نسخة محفوظة")
            .WithApprove((_, _) => Approve(), "🔒 اعتماد التسليم وخصم الرصيد من المستودع")
            .WithUnapprove((_, _) => Unapprove(), "إلغاء التسليم وإعادة الكميات للرصيد")
            .WithPrint((_, _) => Print(), "طباعة الإذن (Ctrl+P)")
            .WithExcel((_, _) => Export())
            .WithNavigation((_, _) => Nav(0), (_, _) => Nav(-1), (_, _) => Nav(1), (_, _) => Nav(int.MaxValue))
            .WithList((_, _) => RefreshList(), "عرض كل أذونات التسليم")
            .WithCustom("💰 تسجيل فوترة", "ErpButton", (_, _) => MarkInvoiced(),
                "تسجيل الكمية المفوترة من السند المعتمد — يمنع تكرار الفوترة لنفس الكمية")
            .WithCustom("⎘ تكرار الصف", "ErpButton", (_, _) => DuplicateRow_Delivery(null,null), "تكرار الصف (7-ج)")
            .WithCustom("🗑 حذف المسودة", "ErpDangerButton", (_, _) => DeleteDraft(),
                "§B105: حذف سند مسودة غير معتمد (لم يخصم شيئاً) — المعتمد لا يُحذف")
            .WithExit((_, _) => (Window.GetWindow(this) as MainWindow)?.OpenPreviousScreen());
        chrome.SetToolbar(_toolbar);
        chrome.SetBody(this);
        chrome.CloseRequested += (_, _) => (Window.GetWindow(this) as MainWindow)?.OpenPreviousScreen();
    }

    private void Load()
    {
        try
        {
            using var scope = AppContainer.NewScope();
            var db = scope.ServiceProvider.GetRequiredService<DatesErpDbContext>();
            CustomerBox.ItemsSource = db.Customers.Where(c => c.IsActive).ToList();
            NewForm();

            // §التنقل من التقارير: فتح سند تسليم محدد فور تحميل الشاشة
            if (MainWindow.PendingDeliveryIdToOpen is int pendingDlv)
            {
                MainWindow.PendingDeliveryIdToOpen = null;
                OpenDelivery(pendingDlv);
            }
        }
        catch (Exception ex) { AppContainer.Get<DialogService>().HandleException(ex, "Delivery.Load"); }
    }

    private void RefreshList()
    {
        try
        {
            using var scope = AppContainer.NewScope();
            var db = scope.ServiceProvider.GetRequiredService<DatesErpDbContext>();
            var list = db.CustomerDeliveries.OrderByDescending(d => d.Id).ToList();
            _deliveryIds = list.Select(d => d.Id).ToList();
            _deliveries_all = list.Select(d => new
            {
                Id = d.Id,
                DocNo = d.DocumentNumber,
                Customer = db.Customers.Where(c => c.Id == d.CustomerId).Select(c => c.CustomerName).FirstOrDefault() ?? "—",
                Date = Core.Common.UiFormat.D(d.DeliveryDate),
                Packages = d.TotalCartons,
                Qty = d.TotalQtyKg,
                StatusAr = d.IsApproved ? "معتمد ✅" : (d.Status == "Hold" ? "معلق 🟡" : "مسودة ⚪")
            }).ToList().Cast<object>().ToList();
            ScreenSearch.Apply(DelivSearchBox, DeliveriesGrid, _deliveries_all);
        }
        catch (Exception ex) { AppContainer.Get<DialogService>().HandleException(ex, "Delivery.List"); }
    }

    private void UndoSmart()
    {
        if (_currentId > 0) OpenDelivery(_currentId);
        else NewForm();
    }

    private void Customer_Changed(object sender, SelectionChangedEventArgs e)
    {
        var cust = CustomerBox.SelectedItem as Core.Domain.Entities.Customer;
        _balances.Clear();
        if (cust == null)
        {
            _currentCustomerId = 0;
            AutoBoundCard.Visibility = Visibility.Collapsed;
            DispCustName.Text = "—";
            BalanceChip.Text = "رصيد العميل: —";
            UpdateSummary();
            return;
        }

        _currentCustomerId = cust.Id;
        AutoBoundCard.Visibility = Visibility.Visible;
        DispCustName.Text = $"{cust.CustomerName} ({cust.CustomerCode})";

        try
        {
            using var scope = AppContainer.NewScope();
            var db = scope.ServiceProvider.GetRequiredService<DatesErpDbContext>();
            var pick = scope.ServiceProvider.GetRequiredService<DatesErp.Application.Services.DeliveryPickService>();
            var rows = pick.GetPickList(cust.Id, DateTime.Now);
            foreach (var r in rows)
            {
                var (ready, qcLabel) = DatesErp.Application.Services.QualityGate.DeliveryReadiness(db, r.LotId, r.ProductId);
                _balances.Add(new DelivBalanceRow
                {
                    ProductId = r.ProductId,
                    LotId = r.LotId,
                    WarehouseId = r.WarehouseId,
                    WarehouseName = r.WarehouseName ?? "WFG (مخزن التام)",
                    PackagingTypeId = r.PackagingTypeId,
                    ProductName = r.ProductName,
                    LotCode = r.LotCode,
                    UnitWeight = r.CartonWeightKg,
                    PackName = r.PackName,
                    Unit = UnitsPolicy.FinishedOfficialUnit,
                    AvailableQty = r.AvailableKg,
                    AvailablePackages = r.AvailableCartons,
                    Packages = r.AvailableCartons,
                    Qty = r.AvailableKg,
                    QcStatus = qcLabel,
                    QcReady = ready,
                    Code = r.ProductCode,
                    Grade = r.GradeAr,
                    CartonWeight = r.CartonWeightKg,
                    FgReceipt = r.FgReceiptDate,
                    Production = r.ProductionDate,
                    StorageDays = r.StorageDays,
                    PlanNo = r.PlanNo,
                    OrderNo = r.OrderNo
                });
            }
            BalanceChip.Text = $"رصيد العميل المتاح: {rows.Sum(r => r.AvailableCartons):N0} كرتون / {rows.Sum(r => r.AvailableKg):N1} كجم";
            double kgOnly = rows.Where(r => r.AvailableCartons <= 0 && r.AvailableKg > 0.001).Sum(r => r.AvailableKg);
            if (kgOnly > 0.001)
                BalanceChip.Text += $"   ⚠ كجم فقط (بلا وزن كرتون): {kgOnly:N1} كجم";
        }
        catch (Exception ex) { AppContainer.Get<DialogService>().HandleException(ex, "Delivery.Balance"); }
        UpdateSummary();
    }

    private void Balance_DoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
    {
        if (_locked) { AppContainer.Get<DialogService>().Error("السند مقفل (معتمد)."); return; }
        if (BalanceGrid.SelectedItem is DelivBalanceRow row)
        {
            if (row.QcStatus != null && row.QcStatus.StartsWith("⛔"))
            { AppContainer.Get<DialogService>().Error($"لا يمكن تسليم هذه البضاعة: {row.QcStatus} — معالجة قرار الجودة أولاً."); return; }
            if (!row.QcReady)
                AppContainer.Get<DialogService>().Info($"تنبيه جودة: فحص الجودة لهذه الدفعة ليس معتمداً بعد ({row.QcStatus}). لن يُسمح باعتماد التسليم حتى يعتمد الفحص.");

            var existing = _items.FirstOrDefault(i => i.ProductId == row.ProductId && i.LotId == row.LotId);
            if (existing != null)
            {
                existing.Packages = row.Packages;
                existing.Qty = row.Qty;
            }
            else
            {
                var empty = _items.FirstOrDefault(i => i.IsEmptyRow);
                if (empty != null) _items.Remove(empty);
                _items.Add(new DelivBalanceRow
                {
                    ProductId = row.ProductId, LotId = row.LotId, WarehouseId = row.WarehouseId, WarehouseName = row.WarehouseName,
                    PackagingTypeId = row.PackagingTypeId, ProductName = row.ProductName,
                    LotCode = row.LotCode, Qty = row.Qty, Packages = row.Packages, UnitWeight = row.UnitWeight,
                    PackName = row.PackName, Unit = row.Unit, QcStatus = row.QcStatus, QcReady = row.QcReady,
                    Code = row.Code, Grade = row.Grade, CartonWeight = row.CartonWeight,
                    FgReceipt = row.FgReceipt, Production = row.Production, StorageDays = row.StorageDays,
                    PlanNo = row.PlanNo, OrderNo = row.OrderNo,
                    AvailableQty = row.AvailableQty, AvailablePackages = row.AvailablePackages
                });
            }
            EnsureEmptyRow();
            UpdateSummary();
        }
    }

    private void DeliverAll_Click(object sender, RoutedEventArgs e)
    {
        if (_locked) { AppContainer.Get<DialogService>().Error("السند مقفل (معتمد)."); return; }
        if (_currentCustomerId == 0)
        {
            AppContainer.Get<DialogService>().Info("يرجى اختيار العميل أولاً لتنزيل كافة دفعاته المتاحة.");
            CustomerBox.Focus();
            return;
        }
        if (_balances.Count == 0)
        {
            AppContainer.Get<DialogService>().Info("لا توجد دفعات إنتاج تام متاحة في WFG لهذا العميل حالياً.");
            return;
        }

        _items.Clear();
        foreach (var b in _balances.Where(b => (b.AvailablePackages > 0 || b.Packages > 0) && b.QcReady))
        {
            _items.Add(new DelivBalanceRow
            {
                ProductId = b.ProductId,
                LotId = b.LotId,
                WarehouseId = b.WarehouseId,
                WarehouseName = b.WarehouseName ?? "WFG (مخزن التام)",
                PackagingTypeId = b.PackagingTypeId,
                ProductName = b.ProductName,
                LotCode = b.LotCode,
                PackName = b.PackName,
                Unit = b.Unit,
                CartonWeight = b.CartonWeight,
                UnitWeight = b.UnitWeight,
                AvailableQty = b.AvailableQty > 0 ? b.AvailableQty : b.Qty,
                AvailablePackages = b.AvailablePackages > 0 ? b.AvailablePackages : b.Packages,
                Packages = b.AvailablePackages > 0 ? b.AvailablePackages : b.Packages,
                Qty = b.AvailableQty > 0 ? b.AvailableQty : b.Qty,
                Production = b.Production,
                Code = b.Code,
                Grade = b.Grade,
                RowNotes = "تسليم كامل الدفعة المتاحة للعميل"
            });
        }
        EnsureEmptyRow();
        UpdateSummary();
        AppContainer.Get<DialogService>().Info($"تم إنزال كافة الدفعات المتاحة ({_items.Count(i => !i.IsEmptyRow)} دفعة) لسلة التسليم بنجاح.");
    }

    private void OpenStockPicker_Click(object sender, RoutedEventArgs e)
    {
        if (_locked) { AppContainer.Get<DialogService>().Error("السند مقفل (معتمد)."); return; }
        if (_currentCustomerId == 0)
        {
            AppContainer.Get<DialogService>().Info("يرجى اختيار العميل أولاً من القائمة لعرض الدفعات التامة المتاحة له في مخزن التام.");
            CustomerBox.Focus();
            return;
        }

        try
        {
            var dlg = new Views.FinishedBatchPickerWindow(_currentCustomerId) { Owner = Window.GetWindow(this) };
            if (dlg.ShowDialog() == true && dlg.SelectedBatch != null)
            {
                var b = dlg.SelectedBatch;
                var existing = _items.FirstOrDefault(i => i.ProductId == b.ProductId && i.LotId == b.LotId);
                if (existing != null)
                {
                    existing.Packages = b.Packages;
                    existing.Qty = b.Qty;
                }
                else
                {
                    var empty = _items.FirstOrDefault(i => i.IsEmptyRow);
                    if (empty != null) _items.Remove(empty);

                    _items.Add(new DelivBalanceRow
                    {
                        ProductId = b.ProductId,
                        LotId = b.LotId,
                        WarehouseId = b.WarehouseId,
                        WarehouseName = b.WarehouseName ?? "WFG (مخزن التام)",
                        PackagingTypeId = b.PackagingTypeId,
                        ProductName = b.ProductName,
                        LotCode = b.LotCode,
                        PackName = b.PackName,
                        Unit = b.Unit,
                        CartonWeight = b.CartonWeight,
                        UnitWeight = b.CartonWeight,
                        AvailableQty = b.Qty,
                        AvailablePackages = b.Packages,
                        Packages = b.Packages,
                        Qty = b.Qty,
                        Production = b.ProductionDate?.ToString("dd/MM/yyyy") ?? "—",
                        Code = b.Grade,
                        Grade = b.Grade
                    });
                }
                EnsureEmptyRow();
                UpdateSummary();
            }
        }
        catch (Exception ex) { AppContainer.Get<DialogService>().HandleException(ex, "Delivery.StockPicker"); }
    }

    private void ClearBasket_Click(object sender, RoutedEventArgs e)
    {
        if (_locked) return;
        _items.Clear();
        EnsureEmptyRow();
        UpdateSummary();
    }

    private void UpdateSummary()
    {
        int idx = 1;
        foreach (var item in _items)
        {
            if (!item.IsEmptyRow) item.RowIndex = idx++;
        }

        var valid = _items.Where(i => !i.IsEmptyRow).ToList();
        int totCartons = valid.Sum(i => i.Packages);
        double totWeight = valid.Sum(i => i.Qty);
        int totProds = valid.Select(i => i.ProductId).Distinct().Count();
        int totLots = valid.Where(i => i.LotId != null).Select(i => i.LotId).Distinct().Count();

        if (TotCartonsDisp != null) TotCartonsDisp.Text = $"{totCartons:N0} كرتون";
        if (TotWeightDisp != null) TotWeightDisp.Text = $"{totWeight:N2} كجم";
        if (TotProdsDisp != null) TotProdsDisp.Text = totProds.ToString();
        if (TotLotsDisp != null) TotLotsDisp.Text = totLots.ToString();
    }

    private static string PackNotes(string vehicle, string driver, string container, string userNotes)
    {
        var meta = new List<string>();
        if (!string.IsNullOrWhiteSpace(vehicle)) meta.Add($"شاحنة: {vehicle.Trim()}");
        if (!string.IsNullOrWhiteSpace(driver)) meta.Add($"سائق: {driver.Trim()}");
        if (!string.IsNullOrWhiteSpace(container)) meta.Add($"حاوية: {container.Trim()}");
        string header = meta.Count > 0 ? $"[{string.Join(" | ", meta)}] " : "";
        return (header + (userNotes ?? "")).Trim();
    }

    private static (string vehicle, string driver, string container, string userNotes) UnpackNotes(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw)) return ("", "", "", "");
        string v = "", d = "", c = "", n = raw;
        if (raw.StartsWith("[") && raw.Contains("]"))
        {
            int end = raw.IndexOf(']');
            string metaPart = raw.Substring(1, end - 1);
            n = raw.Substring(end + 1).Trim();
            var parts = metaPart.Split('|');
            foreach (var p in parts)
            {
                var kv = p.Split(':');
                if (kv.Length == 2)
                {
                    var key = kv[0].Trim();
                    var val = kv[1].Trim();
                    if (key.Contains("شاحنة") || key.Contains("لوحة")) v = val;
                    else if (key.Contains("سائق")) d = val;
                    else if (key.Contains("حاوية") || key.Contains("بوليصة")) c = val;
                }
            }
        }
        return (v, d, c, n);
    }

    private void RemoveRow_Click(object sender, RoutedEventArgs e)
    {
        if (_locked) { AppContainer.Get<DialogService>().Error("السند مقفل (معتمد)."); return; }
        if (ItemsGrid.SelectedItem is DelivBalanceRow row) { _items.Remove(row); EnsureEmptyRow(); UpdateSummary(); }
    }

    private void RemoveItem_Click(object sender, RoutedEventArgs e)
    {
        if (_locked) return;
        if (sender is Button b && b.Tag is DelivBalanceRow row)
        {
            _items.Remove(row);
            EnsureEmptyRow();
            UpdateSummary();
        }
    }

    private void Save_Click(object sender, RoutedEventArgs e) => Save();
    private void NewForm_Click(object sender, RoutedEventArgs e) => NewForm();
    private void Undo_Click(object sender, RoutedEventArgs e) => UndoSmart();
    private void OpenLookup_Click(object sender, RoutedEventArgs e) => FocusDeliveries();
    private void Print_Click(object sender, RoutedEventArgs e) => Print();
    private void FocusDeliveries_Click(object sender, RoutedEventArgs e) => FocusDeliveries();
    private void OpenBalances_Click(object sender, RoutedEventArgs e) => (Window.GetWindow(this) as MainWindow)?.OpenScreen("balances");
    private void CloseWin_Click(object sender, RoutedEventArgs e) => (Window.GetWindow(this) as MainWindow)?.OpenPreviousScreen();

    private void FocusDeliveries()
    {
        RefreshList();
        DelivSearchBox.Focus();
        if (DeliveriesGrid.Items.Count > 0) DeliveriesGrid.ScrollIntoView(DeliveriesGrid.Items[0]);
    }

    private void Save()
    {
        try
        {
            if (_locked) { AppContainer.Get<DialogService>().Error("السند مقفل (معتمد)."); return; }
            if (_currentCustomerId == 0) { AppContainer.Get<DialogService>().Error("اختر العميل."); return; }
            var broken = _items.Where(r => !r.IsEmptyRow && r.ProductId != 0 && r.Packages <= 0).ToList();
            if (broken.Count > 0)
            {
                string detail = string.Join("؛ ", broken.Select(r => $"{r.ProductName} / {r.LotCode}"));
                AppContainer.Get<DialogService>().Error($"لا يمكن حفظ السند — البنود التالية بلا كراتين صالحة: {detail}\nعدّل الكراتين (أكبر من 0) أو احذف الصف.");
                return;
            }
            var validItems = _items.Where(r => !r.IsEmptyRow && r.ProductId != 0 && r.Packages > 0).ToList();
            if (validItems.Count == 0) { AppContainer.Get<DialogService>().Error("أضف بنداً من رصيد العميل (نقر مزدوج أو زر إنزال الدفعات أو اختيار من المخزون)."); return; }

            using var scope = AppContainer.NewScope();
            var svc = (ICustomerDeliveryService)scope.ServiceProvider.GetService(typeof(ICustomerDeliveryService));
            int? orderId = null;
            {
                using var oscope = AppContainer.NewScope();
                var odb = oscope.ServiceProvider.GetRequiredService<DatesErpDbContext>();
                var firstLot = _items.FirstOrDefault(i => i.LotId != null)?.LotId;
                if (firstLot != null)
                    orderId = odb.ProductionOrderItems.AsNoTracking()
                        .Where(i => i.LotId == firstLot).OrderBy(i => i.Id)
                        .Select(i => (int?)i.OrderId).FirstOrDefault();
            }

            var itemsDto = validItems.Select(i => new CustomerDeliveryItemDto
            {
                WarehouseId = i.WarehouseId, ProductId = i.ProductId, LotId = i.LotId, PackagingTypeId = i.PackagingTypeId,
                QtyKg = i.Qty, PackageCount = i.Packages
            }).ToList();

            string packedNotes = PackNotes(VehicleBox.Text, DriverBox.Text, ContainerBox.Text, NotesBox.Text);

            OpResult r = _currentId > 0 && !_locked
                ? svc.Update(_currentId, _currentCustomerId, (DateBox.SelectedDate ?? DateTime.Now).ToString("dd/MM/yyyy"), orderId, itemsDto)
                : svc.Save(_currentCustomerId, (DateBox.SelectedDate ?? DateTime.Now).ToString("dd/MM/yyyy"), orderId, itemsDto);

            if (!r.Ok) { AppContainer.Get<DialogService>().Error(r.Message); return; }

            _currentId = r.Id;
            DocNoBox.Text = r.DocumentNumber;

            // حفظ الملاحظات والحالة الخاصة
            using (var dbScope = AppContainer.NewScope())
            {
                var db = dbScope.ServiceProvider.GetRequiredService<DatesErpDbContext>();
                var doc = db.CustomerDeliveries.FirstOrDefault(d => d.Id == _currentId);
                if (doc != null)
                {
                    doc.Notes = packedNotes;
                    if (HoldRadio.IsChecked == true && !doc.IsApproved) doc.Status = "Hold";
                    db.SaveChanges();
                }
            }

            // فحص خيار الاعتماد الفوري
            if (ApproveRadio.IsChecked == true)
            {
                var apprRes = svc.Approve(_currentId);
                if (!apprRes.Ok)
                {
                    AppContainer.Get<DialogService>().Error($"تم حفظ السند، ولكن تعذر الاعتماد والصرف المخزني: {apprRes.Message}");
                    RefreshList();
                    OpenDelivery(_currentId);
                    return;
                }
                AppContainer.Get<DialogService>().Info($"تم حفظ وإصدار سند تسليم العميل {r.DocumentNumber} بنجاح، وخُصمت الكميات فورياً من مستودع التام WFG.");
                SetLocked(true);
            }
            else
            {
                AppContainer.Get<DialogService>().Info($"تم حفظ سند التسليم {r.DocumentNumber} كمسودة بنجاح.");
            }

            RefreshList();
            OpenDelivery(_currentId);
        }
        catch (Exception ex) { AppContainer.Get<DialogService>().HandleException(ex, "Delivery.Save"); }
    }

    private void Approve()
    {
        try
        {
            if (_currentId == 0) { AppContainer.Get<DialogService>().Error("احفظ سند التسليم أولاً."); return; }
            if (!AppContainer.Get<DialogService>().Confirm("الاعتماد سيخصم الكميات نهائياً من رصيد العميل في مخزن التام WFG ويصدر إذن الخروج. متابعة؟")) return;
            using var scope = AppContainer.NewScope();
            var svc = (ICustomerDeliveryService)scope.ServiceProvider.GetService(typeof(ICustomerDeliveryService));
            var r = svc.Approve(_currentId);
            if (!r.Ok) { AppContainer.Get<DialogService>().Error(r.Message); return; }
            AppContainer.Get<DialogService>().Info($"تم اعتماد إذن التسليم وصرف {r.Message} من المستودع بنجاح.");
            SetLocked(true);
            Customer_Changed(null, null);
            RefreshList();
            OpenDelivery(_currentId);
        }
        catch (Exception ex) { AppContainer.Get<DialogService>().HandleException(ex, "Delivery.Approve"); }
    }

    private void Unapprove()
    {
        try
        {
            if (_currentId == 0) return;
            if (!AppContainer.Get<DialogService>().Confirm("إلغاء التسليم سيعيد الكميات المصروفة إلى رصيد العميل بالمستودع. متابعة؟")) return;
            using var scope = AppContainer.NewScope();
            var svc = (ICustomerDeliveryService)scope.ServiceProvider.GetService(typeof(ICustomerDeliveryService));
            var r = svc.Unapprove(_currentId);
            if (!r.Ok) { AppContainer.Get<DialogService>().Error(r.Message); return; }
            AppContainer.Get<DialogService>().Info(r.Message);
            SetLocked(false);
            Customer_Changed(null, null);
            RefreshList();
            OpenDelivery(_currentId);
        }
        catch (Exception ex) { AppContainer.Get<DialogService>().HandleException(ex, "Delivery.Unapprove"); }
    }

    private void DeleteDraft()
    {
        if (_currentId == 0) { AppContainer.Get<DialogService>().Error("لا يوجد سند محفوظ ومفتوح لحذفه."); return; }
        if (_locked) { AppContainer.Get<DialogService>().Error("السند معتمد — لا يُحذف. ألغِ الاعتماد أولاً إن لزم التصحيح."); return; }
        if (!AppContainer.Get<DialogService>().Confirm($"حذف سند التسليم المسودة {DocNoBox.Text}؟")) return;
        try
        {
            using var scope = AppContainer.NewScope();
            var svc = (ICustomerDeliveryService)scope.ServiceProvider.GetService(typeof(ICustomerDeliveryService));
            var r = svc.DeleteDraft(_currentId);
            if (!r.Ok) { AppContainer.Get<DialogService>().Error(r.Message); return; }
            AppContainer.Get<DialogService>().Info(r.Message);
            NewForm();
            RefreshList();
        }
        catch (Exception ex) { AppContainer.Get<DialogService>().HandleException(ex, "Delivery.DeleteDraft"); }
    }

    private void NewForm()
    {
        _currentId = 0;
        _items.Clear();
        try
        {
            using var _numScope = AppContainer.NewScope();
            var _num = _numScope.ServiceProvider.GetRequiredService<INumberingService>().Peek("CD");
            DocNoBox.Text = _num;
        }
        catch { DocNoBox.Text = "CDL-2026-xxxx (تلقائي)"; }
        DateBox.SelectedDate = DateTime.Now;
        ContainerBox.Text = "";
        DriverBox.Text = "";
        VehicleBox.Text = "";
        NotesBox.Text = "";
        AutoBoundCard.Visibility = Visibility.Collapsed;
        DispCustName.Text = "—";
        DraftRadio.IsChecked = true;
        StatusBadge.Text = "جديد / قيد التحرير 🟡";
        StatusBadge.Foreground = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0x00, 0x80, 0x00));
        DateDispText.Text = "التاريخ: " + DateTime.Today.ToString("dd/MM/yyyy");
        try
        {
            var u = AppContainer.Get<ICurrentSession>()?.UserName ?? "admin";
            UserDispText.Text = u;
            AuditUserText.Text = u;
        }
        catch { UserDispText.Text = "admin"; AuditUserText.Text = "admin"; }

        SetLocked(false);
        AddEmptyRow();
        UpdateSummary();
    }

    private void AddEmptyRow()
    {
        _items.Add(new DelivBalanceRow());
    }

    private void EnsureEmptyRow()
    {
        if (_locked) return;
        if (_items.Count == 0 || !_items.Last().IsEmptyRow)
            AddEmptyRow();
    }

    private void AddEmptyRow_Click(object sender, RoutedEventArgs e)
    {
        if (_locked) return;
        AddEmptyRow();
        UpdateSummary();
    }

    private void ImportExcel_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            if (_locked) { AppContainer.Get<DialogService>().Error("السند مقفل (معتمد)."); return; }
            if (_currentCustomerId == 0) { AppContainer.Get<DialogService>().Error("اختر العميل أولاً ثم استورد البنود."); return; }
            var dlg = new Microsoft.Win32.OpenFileDialog
            {
                Filter = "Excel (*.xlsx)|*.xlsx|CSV (*.csv)|*.csv",
                Title = "اختر ملف بنود التسليم (LotCode, ProductCode, Cartons)"
            };
            if (dlg.ShowDialog() != true) return;

            var imported = 0;
            var skipped = new List<string>();
            void Add(string lotCode, string productCode, string cartonsText, int lineNo)
            {
                lotCode = lotCode.Trim(); productCode = productCode.Trim();
                if (!int.TryParse(cartonsText.Trim(), out var cartons) || cartons <= 0)
                { skipped.Add($"السطر {lineNo}: عدد كراتين غير صالح"); return; }
                var source = _balances.FirstOrDefault(b =>
                    string.Equals(b.LotCode, lotCode, StringComparison.OrdinalIgnoreCase) &&
                    (string.IsNullOrWhiteSpace(productCode) || string.Equals(b.Code, productCode, StringComparison.OrdinalIgnoreCase)));
                if (source == null)
                { skipped.Add($"السطر {lineNo}: الدفعة {lotCode} غير موجودة في رصيد العميل"); return; }
                if (cartons > source.AvailablePackages)
                { skipped.Add($"السطر {lineNo}: {cartons} كرتون أكبر من المتاح {source.AvailablePackages}"); return; }
                var target = _items.FirstOrDefault(i => i.LotId == source.LotId && i.ProductId == source.ProductId && i.PackagingTypeId == source.PackagingTypeId);
                if (target == null)
                {
                    target = new DelivBalanceRow
                    {
                        ProductId = source.ProductId, LotId = source.LotId, WarehouseId = source.WarehouseId, WarehouseName = source.WarehouseName,
                        PackagingTypeId = source.PackagingTypeId,
                        ProductName = source.ProductName, LotCode = source.LotCode, UnitWeight = source.UnitWeight,
                        PackName = source.PackName, Unit = source.Unit, QcStatus = source.QcStatus, QcReady = source.QcReady,
                        Code = source.Code, Grade = source.Grade, CartonWeight = source.CartonWeight,
                        AvailableQty = source.AvailableQty, AvailablePackages = source.AvailablePackages
                    };
                    _items.Add(target);
                }
                target.Packages = cartons;
                imported++;
            }

            if (dlg.FileName.EndsWith(".csv", StringComparison.OrdinalIgnoreCase))
            {
                var lines = System.IO.File.ReadAllLines(dlg.FileName);
                for (var i = 1; i < lines.Length; i++)
                {
                    var cells = lines[i].Split(',');
                    if (cells.Length >= 3) Add(cells[0], cells[1], cells[2], i + 1);
                }
            }
            else
            {
                using var wb = new ClosedXML.Excel.XLWorkbook(dlg.FileName);
                var ws = wb.Worksheets.FirstOrDefault();
                if (ws == null) { AppContainer.Get<DialogService>().Error("ملف Excel لا يحتوي ورقة عمل."); return; }
                foreach (var row in ws.RowsUsed().Skip(1))
                    Add(row.Cell(1).GetString(), row.Cell(2).GetString(), row.Cell(3).GetString(), row.RowNumber());
            }
            EnsureEmptyRow();
            UpdateSummary();
            var detail = skipped.Count == 0 ? "" : $"\nتم تجاوز {skipped.Count} سطراً: {string.Join("؛ ", skipped.Take(5))}";
            AppContainer.Get<DialogService>().Info($"تم استيراد {imported} بنداً من الملف.{detail}");
        }
        catch (Exception ex) { AppContainer.Get<DialogService>().HandleException(ex, "Delivery.ImportExcel"); }
    }

    private void LotCode_Click(object sender, RoutedEventArgs e)
    {
        if (_locked) return;
        if (sender is Button b && b.Tag is DelivBalanceRow row)
            OpenBatchPicker(row);
    }

    private void ProductName_Click(object sender, RoutedEventArgs e)
    {
        if (_locked) return;
        if (sender is Button b && b.Tag is DelivBalanceRow row)
            OpenBatchPicker(row);
    }

    private void OpenBatchPicker(DelivBalanceRow row)
    {
        try
        {
            var dlg = new Views.FinishedBatchPickerWindow(_currentCustomerId > 0 ? _currentCustomerId : null) { Owner = Window.GetWindow(this) };
            if (dlg.ShowDialog() == true && dlg.SelectedBatch != null)
            {
                var batch = dlg.SelectedBatch;
                row.ProductId = batch.ProductId;
                row.LotId = batch.LotId;
                row.WarehouseId = batch.WarehouseId;
                row.WarehouseName = batch.WarehouseName ?? "WFG (مخزن التام)";
                row.PackagingTypeId = batch.PackagingTypeId;
                row.ProductName = batch.ProductName;
                row.LotCode = batch.LotCode;
                row.PackName = batch.PackName;
                row.Unit = batch.Unit;
                row.CartonWeight = batch.CartonWeight;
                row.UnitWeight = batch.CartonWeight;
                row.AvailableQty = batch.Qty;
                row.AvailablePackages = batch.Packages;
                row.Qty = batch.Qty;
                row.Packages = batch.Packages;
                row.Production = batch.ProductionDate?.ToString("dd/MM/yyyy") ?? "—";
                EnsureEmptyRow();
                UpdateSummary();
            }
        }
        catch (Exception ex) { AppContainer.Get<DialogService>().HandleException(ex, "Delivery.PickBatch"); }
    }

    private void SetLocked(bool locked)
    {
        _locked = locked;
        CustomerBox.IsEnabled = !locked;
        DateBox.IsEnabled = !locked;
        ContainerBox.IsReadOnly = locked;
        DriverBox.IsReadOnly = locked;
        VehicleBox.IsReadOnly = locked;
        NotesBox.IsReadOnly = locked;
        ItemsGrid.IsReadOnly = locked;
        DraftRadio.IsEnabled = !locked;
        ApproveRadio.IsEnabled = !locked;
        HoldRadio.IsEnabled = !locked;

        if (locked)
        {
            StatusBadge.Text = "معتمد ومصروف 🟢";
            StatusBadge.Foreground = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0x16, 0x65, 0x34));
            ApproveRadio.IsChecked = true;
        }
        else
        {
            StatusBadge.Text = _currentId == 0 ? "جديد / قيد التحرير 🟡" : "مسودة قيد التجهيز ⚪";
            StatusBadge.Foreground = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0x00, 0x80, 0x00));
        }

        if (_toolbar != null)
        {
            if (_toolbar.SaveBtn != null) _toolbar.SaveBtn.IsEnabled = !locked;
            if (_toolbar.ApproveBtn != null) _toolbar.ApproveBtn.IsEnabled = !locked;
            if (_toolbar.UnapproveBtn != null) _toolbar.UnapproveBtn.IsEnabled = locked;
        }
    }

    private void Nav(int dir)
    {
        if (_deliveryIds.Count == 0) return;
        int idx = _deliveryIds.IndexOf(_currentId);
        idx = dir switch { 0 => 0, int.MaxValue => _deliveryIds.Count - 1, _ => Math.Clamp(idx + dir, 0, _deliveryIds.Count - 1) };
        OpenDelivery(_deliveryIds[idx]);
    }

    private void OpenDelivery(int id)
    {
        try
        {
            using var scope = AppContainer.NewScope();
            var db = scope.ServiceProvider.GetRequiredService<DatesErpDbContext>();
            var d = db.CustomerDeliveries.Include(x => x.Items).FirstOrDefault(x => x.Id == id);
            if (d == null) return;
            _currentId = d.Id;
            _currentCustomerId = d.CustomerId;
            CustomerBox.SelectedValue = d.CustomerId;
            DateBox.SelectedDate = d.DeliveryDate;
            DocNoBox.Text = d.DocumentNumber;

            // استرجاع الملاحظات وبيانات السائق والشاحنة
            var (v, dr, c, n) = UnpackNotes(d.Notes);
            VehicleBox.Text = v;
            DriverBox.Text = dr;
            ContainerBox.Text = c;
            NotesBox.Text = n;

            _items.Clear();
            foreach (var it in d.Items)
            {
                var prod0 = db.Products.AsNoTracking().FirstOrDefault(p => p.Id == it.ProductId);
                double w0 = it.PackagingTypeId != null
                    ? db.PackagingTypes.Where(k => k.Id == it.PackagingTypeId).Select(k => k.UnitWeightKg).FirstOrDefault()
                    : 0;
                if (w0 <= 0) w0 = it.CartonWeightKg > 0 ? it.CartonWeightKg : (prod0?.CartonWeightKg > 0 ? prod0.CartonWeightKg : 0);
                if (w0 <= 0)
                {
                    AppContainer.Get<DialogService>().Error($"لا يمكن فتح السند: وزن الكرتون غير معرف للصنف «{prod0?.ProductNameAr ?? it.ProductId.ToString()}» — عرّفه في بطاقة الصنف أولاً.");
                    return;
                }
            }

            foreach (var it in d.Items)
            {
                var prod = db.Products.AsNoTracking().FirstOrDefault(p => p.Id == it.ProductId);
                var lot = db.Lots.AsNoTracking().FirstOrDefault(l => l.Id == it.LotId);
                double unitW = it.PackagingTypeId != null
                    ? db.PackagingTypes.Where(k => k.Id == it.PackagingTypeId).Select(k => k.UnitWeightKg).FirstOrDefault()
                    : 0;
                if (unitW <= 0) unitW = it.CartonWeightKg > 0 ? it.CartonWeightKg : (prod?.CartonWeightKg > 0 ? prod.CartonWeightKg : 0);

                _items.Add(new DelivBalanceRow
                {
                    ProductId = it.ProductId,
                    LotId = it.LotId,
                    WarehouseId = it.WarehouseId,
                    WarehouseName = it.WarehouseId != null ? db.Warehouses.Where(w => w.Id == it.WarehouseId).Select(w => w.WarehouseNameAr).FirstOrDefault() ?? "WFG (مخزن التام)" : "WFG (مخزن التام)",
                    PackagingTypeId = it.PackagingTypeId,
                    ProductName = prod?.ProductNameAr ?? "-",
                    LotCode = lot?.LotCode ?? "—",
                    Qty = it.QtyKg,
                    Packages = it.PackageCount,
                    UnitWeight = unitW,
                    PackName = it.PackagingTypeId != null ? db.PackagingTypes.Where(k => k.Id == it.PackagingTypeId).Select(k => k.PackageNameAr).FirstOrDefault() ?? "—" : "—",
                    Unit = prod?.UnitOfMeasure ?? "—",
                    Production = lot?.LotDate?.ToString("dd/MM/yyyy") ?? "—"
                });
            }

            if (d.IsApproved) ApproveRadio.IsChecked = true;
            else if (d.Status == "Hold") HoldRadio.IsChecked = true;
            else DraftRadio.IsChecked = true;

            SetLocked(d.IsApproved);
            if (!d.IsApproved) EnsureEmptyRow();
            UpdateSummary();
        }
        catch (Exception ex) { AppContainer.Get<DialogService>().HandleException(ex, "Delivery.Open"); }
    }

    private void Print()
    {
        if (_currentId <= 0) { AppContainer.Get<DialogService>().Error("احفظ السند أولًا؛ يمكن معاينة مسودة محفوظة دون اعتمادها. الطباعة تستخدم النسخة المحفوظة فقط."); return; }
        try
        {
            using var scope = AppContainer.NewScope();
            var db = scope.ServiceProvider.GetRequiredService<DatesErpDbContext>();
            var m = Printing.StoredPrintModels.CustomerDelivery(db, _currentId);
            new PrintPreviewWindow(PhasePrint.Build(m), $"{m.DocTitle} {m.DocNo}")
            { Owner = Window.GetWindow(this) }.ShowDialog();
        }
        catch (Exception ex) { AppContainer.Get<DialogService>().HandleException(ex, "DeliveryView.Print"); }
    }

    private void Export()
    {
        var report = new ReportResult
        {
            TitleAr = $"إذن تسليم عميل {DocNoBox.Text}",
            Columns = new List<string> { "الصنف", "الدفعة", "الكمية (كجم)", "العبوات" },
            Rows = _items.Where(i => !i.IsEmptyRow).Select(i => new object[] { i.ProductName, i.LotCode, i.Qty, i.Packages }).ToList()
        };
        AppContainer.Get<ExportPrintService>().ExportExcel(report);
    }

    private void DeliveriesGrid_DoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
    {
        if (DeliveriesGrid.SelectedItem?.GetType().GetProperty("Id")?.GetValue(DeliveriesGrid.SelectedItem) is int id)
            OpenDelivery(id);
    }

    private void MarkInvoiced()
    {
        if (_currentId == 0) { AppContainer.Get<DialogService>().Error("افتح سند تسليم معتمداً أولاً."); return; }
        var dlg = new Views.InputDialog("تسجيل فوترة", "الكمية المفوترة (كجم):") { Owner = Window.GetWindow(this) };
        if (dlg.ShowDialog() != true) return;
        if (!double.TryParse(dlg.Value, out var qty) || qty <= 0)
        { AppContainer.Get<DialogService>().Error("أدخل كمية صحيحة أكبر من صفر."); return; }
        try
        {
            using var scope = AppContainer.NewScope();
            var svc = scope.ServiceProvider.GetRequiredService<IPlanProgressService>();
            var r = svc.MarkInvoiced(_currentId, qty);
            if (!r.Ok) { AppContainer.Get<DialogService>().Error(r.Message); return; }
            AppContainer.Get<DialogService>().Info(r.Message);
            RefreshList();
        }
        catch (Exception ex) { AppContainer.Get<DialogService>().HandleException(ex, "Delivery.Invoice"); }
    }

    private void DelivSearch_Changed(object sender, System.Windows.Controls.TextChangedEventArgs e)
        => ScreenSearch.Apply(DelivSearchBox, DeliveriesGrid, _deliveries_all);

    private void DuplicateRow_Delivery(object sender, RoutedEventArgs e)
    {
        if (_locked) return;
        var src = ItemsGrid.SelectedItem as DelivBalanceRow ?? _items.LastOrDefault(x => !x.IsEmptyRow);
        if (src == null) return;
        _items.Add(new DelivBalanceRow
        {
            ProductId = src.ProductId, LotId = src.LotId, PackagingTypeId = src.PackagingTypeId,
            ProductName = src.ProductName, LotCode = src.LotCode,
            Qty = src.Qty, Packages = src.Packages, UnitWeight = src.UnitWeight,
            PackName = src.PackName, Unit = src.Unit,
            AvailableQty = src.AvailableQty, AvailablePackages = src.AvailablePackages
        });
        UpdateSummary();
    }

    private void ItemsGrid_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
    {
        if (_locked) return;
        if (e.Key == System.Windows.Input.Key.F2) { AddEmptyRow(); e.Handled = true; }
        else if (e.Key == System.Windows.Input.Key.F10) { Save(); e.Handled = true; }
        else if (e.Key == System.Windows.Input.Key.Enter)
        {
            if (ItemsGrid.CurrentColumn != null)
            {
                int idx = ItemsGrid.Columns.IndexOf(ItemsGrid.CurrentColumn);
                if (idx < ItemsGrid.Columns.Count - 1)
                {
                    ItemsGrid.CurrentCell = new DataGridCellInfo(ItemsGrid.SelectedItem, ItemsGrid.Columns[idx + 1]);
                    ItemsGrid.BeginEdit(); e.Handled = true;
                }
                else
                {
                    int rIdx = _items.IndexOf(ItemsGrid.SelectedItem as DelivBalanceRow);
                    if (rIdx >= 0 && rIdx < _items.Count - 1)
                    {
                        ItemsGrid.SelectedIndex = rIdx + 1;
                        ItemsGrid.CurrentCell = new DataGridCellInfo(_items[rIdx + 1], ItemsGrid.Columns[1]);
                        ItemsGrid.BeginEdit();
                    }
                    else AddEmptyRow();
                    e.Handled = true;
                }
            }
        }
        else if (e.Key == System.Windows.Input.Key.Down)
        {
            int rIdx = _items.IndexOf(ItemsGrid.SelectedItem as DelivBalanceRow);
            if (rIdx == _items.Count - 1) AddEmptyRow();
        }
    }
}
